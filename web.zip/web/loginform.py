from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired


class LoginForm(FlaskForm):
    id_user = StringField('Id астронавта', validators=[DataRequired()])
    password_user = PasswordField('Пароль астронавта', validators=[DataRequired()])
    id_main = StringField('Id капитана', validators=[DataRequired()])
    password_main = PasswordField('Пароль капитана', validators=[DataRequired()])
    submit = SubmitField('Доступ')