import json
import os

from django.shortcuts import redirect
from flask import render_template, Flask, request

from loginform import LoginForm
from web.photoform import PhotoForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

@app.route('/')
@app.route('/index/<new_title>')
def index(new_title):
    return render_template('login.html', title=new_title)

@app.route('/training/<prof>')
def training(prof):
    return render_template('training.html', prof=prof)

@app.route('/answer')
@app.route('/auto_answer')
def answer():
    p = {
        'title': 'Миссия на Марсе',
    'surname': 'Ast',
    'name': 'Alex',
    'education': 'среднее',
    'profession': 'программист',
    'sex': 'male',
    'motivation': 'Хочу полетать в космосе',
    'ready': 'True'
    }
    return render_template('auto_answer.html', **p)

@app.route('/list_prof/<list>')
def list_prof(list):
    professions = ['инженер-исследователь', 'пилот', 'строитель', 'экзобиолог',
                   'врач',
                   'инженер по терраформированию', 'климатолог',
                   'специалист по радиационной защите', 'астрогеолог',
                   'гляциолог',
                   'инженер жизнеобеспечения', 'метеоролог',
                   'оператор марсохода', 'киберинженер',
                   'штурман', 'пилот дронов']
    return render_template('list_prof.html', prof=professions, type=list)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        return redirect('/success')
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/distribution')
def distribution():
    people = ['Ридли Скотт', 'Энди Уир', 'Марк Уотни', 'Венката Капур', 'Тедди Сандерс', 'Шон Бин']
    return render_template('distribution.html', people=people)

@app.route('/table/<sex>/<age>')
def table(sex, age):
    return render_template('table.html', sex=sex, age=int(age))

@app.route('/carousel', methods=['GET', 'POST'])
def carousel():
    images = os.listdir('static/img')
    form = PhotoForm()
    if request.method == 'POST':
        form.photo.data.save(f'static/img/{form.photo.data.filename}')
        images = os.listdir('static/img')
    return render_template('carousel.html', form=form, images=images)

@app.route('/member')
def member():
    with open('templates/users.json', 'r', encoding='utf-8') as f:
        info = json.load(f)
    return render_template('member.html', info=info)

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')